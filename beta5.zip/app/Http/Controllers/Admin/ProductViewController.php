<?php

namespace App\Http\Controllers\Admin;
use App\BL\BLProduct;
use App\Category;
use App\Enums\SaveResult;
use App\Http\Controllers\Controller;
use App\Http\Requests\ProductRequest;
use App\Unit;
use DB;
use Http\Client\Exception\HttpException;
use HttpRequestException;
use Illuminate\Http\Request;

class ProductViewController extends Controller
{
    public function productView(){
        try{
            $products =  DB::table('product as A')
                ->join('category as B', 'B.id', '=', 'A.category_id')
                ->join('unit as C', 'C.id', '=', 'A.unit_id')
                ->select('A.id', 'A.cod_fs', 'A.item', 'A.name', 'A.pronunciation_in_english', 'A.description', 'A.packsize', 'A.picture_url','A.category_id','A.unit_id','A.active', DB::raw('B.name as categoryp'),  DB::raw('C.name as unitp'))
                ->get();

            $categories = Category::all();
            $units = Unit::all();

            return view('admin.product',compact('products','categories', 'units'));

        }catch (HttpRequestException $ex){

            return back()->withErrors('error',$ex);
        }
    }

    public function productStore(ProductRequest $request){

        $validation =  BLProduct::store($request);

        switch ($validation) {
            case SaveResult::SUCCESS:
                return redirect()->route('productos')->with('success', 'El producto se ha guardado correctamente.');
            case SaveResult::INTERNAL_ERROR:
                return redirect()->route('productos')->with('error', 'El producto no pudo ser guardado.');
            case SaveResult::EXISTING_DATA:
                return redirect()->route('productos')->with('error', 'El producto ya existe académico ya existe.');
        }

    }




    public function categoryView(){
        return view('admin.category');
    }

    public function unitView(){
        return view('admin.unit');
    }

}
