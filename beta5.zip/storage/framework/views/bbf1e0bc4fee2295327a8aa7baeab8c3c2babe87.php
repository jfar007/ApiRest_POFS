<?php $__env->startSection('content'); ?>

    <div class="row tile_count">

        <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
            <span class="count_top"><i class="fa fa-user"></i> Productos Disponibles</span>
            <div class="count">2500</div>

        </div>

        <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
            <span class="count_top"><i class="fa fa-clock-o"></i> Pedidos Total</span>
            <div class="count">80</div>
           
        </div>
        <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
            <span class="count_top"><i class="fa fa-user"></i> Productos Ultimo Pedido</span>
            <div class="count">12</div>
        </div>
        <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
            <span class="count_top"><i class="fa fa-calendar"></i>Fecha Ultimo Pedido</span>
            <div class="count " style="color: #662482;"> <span style="font-size: 24px">14/03/2019</span></div>
        </div>

        <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
            <span class="count_top"><i class="fa fa-user"></i> Productos Sugeridos</span>
            <div class="count">50</div>
        </div>
        <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
            <span class="count_top"><i class="fa fa-user"></i> Catetorias Productos</span>
            <div class="count">15</div>
        </div>
    </div>





<?php $__env->stopSection(); ?>



<?php $__env->startSection('styles'); ?>
    ##parent-placeholder-bf62280f159b1468fff0c96540f3989d41279669##
    

    <link rel="stylesheet" href="<?php echo e(asset('css/tableDynamic.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset('css/customTheme.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/default.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/custom/sideBar.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    ##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
    <script src="<?php echo e(asset('js/tableDynamic.js')); ?>"></script>
    <script src="<?php echo e(asset('js/customTheme.js')); ?>"></script>
    <script src="<?php echo e(asset('js/data.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>