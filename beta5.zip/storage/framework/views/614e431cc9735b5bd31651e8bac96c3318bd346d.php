<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">


       
        


        
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

        

        
        <link rel="stylesheet" href="<?php echo e(asset('css/toastr.css')); ?>">
        
        <?php echo $__env->yieldContent('styles'); ?>

        
        <?php echo $__env->yieldContent('head'); ?>

    </head>
    <body class="<?php echo $__env->yieldContent('body_class'); ?>">

        
        <?php echo $__env->yieldContent('page'); ?>

        
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>

        
        
        <?php echo $__env->yieldContent('scripts'); ?>
        <script src="<?php echo e(asset('js/toastr.js')); ?>"></script>
    </body>
</html>
