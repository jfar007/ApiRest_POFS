<?php $__env->startSection('content'); ?>

    
  


    

    

    <div class="row">

        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Solicitar Pedido <small></small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                            <ul class="dropdown-menu" role="menu">

                            </ul>
                        </li>
                        </li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">


                    <!-- Smart Wizard -->
                    <p>Comience a seleccionar sus productos para una nueva orden</p>
                    <div id="wizard" class="form_wizard wizard_horizontal">
                        <ul class="wizard_steps">
                            <li>
                                <a href="#step-1">
                                    <span class="step_no">1</span>
                                    <span class="step_descr">
                                              Paso 1<br />
                                              <small>Seleccionar todos sus producto</small>
                                          </span>
                                </a>
                            </li>
                            <li>
                                <a href="#step-2">
                                    <span class="step_no">2</span>
                                    <span class="step_descr">
                                              Paso 2<br />
                                              <small>Seleccionar Accion</small>
                                          </span>
                                </a>
                            </li>
                            <li>
                                <a href="#step-3">
                                    <span class="step_no">3</span>
                                    <span class="step_descr">
                                              Paso 3<br />
                                              <small>Realizar Accion</small>
                                          </span>
                                </a>
                            </li>
                           
                        </ul>
                        <div id="step-1">


                            
                            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                                        aria-hidden="true">&times;</span></button>
                                            <h4 class="modal-title text-center" id="myModalLabel">Nuevo Producto</h4>
                                        </div>
                                        <div class="modal-body text-left">
                                            <form onsubmit="">
                                                <?php echo e(csrf_field()); ?>

                                                <div class="form-group">
                                                    <label for="products">Seleccione el producto</label>
                                                    <select  required name="products" class="form-control">
                                                        <option value="">-Seleccione uno-</option>
                                                        <option v-for="value in products.values" ></option>
                                                    </select>
                                                </div>

                                                <div class="form-group">
                                                    <label for="middle-name">Cantidad de Productos</label>

                                                    <input id="middle-name" class="form-control " type="text"
                                                           name="middle-name">
                                                </div>

                                                <div class="form-group">
                                                    <label for="middle-name">Fecha de orden</label>

                                                    <input id="middle-name" class="form-control " type="date"
                                                           name="middle-name">
                                                </div>


                                                <button id="agregar" type="submit" class="btn btn-success"
                                                        onclick="return confirm('Desea Continuar?')">Agregar
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <button type="button" class="btn btn-danger " data-toggle="modal" data-target="#myModal">
                                Agregar Producto
                            </button>

                            
                            <br>
                            <br>

                            
                            <table id="datatable" class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th>CODIGO</th>
                                    <th>DESCRIPCION DEL PRODUCTO</th>
                                    <th>EMPAQUE</th>
                                    <th>UNIDAD DE PEDIDO</th>
                                    <th>CANTIDADES</th>

                                    <th>Acciones</th>

                                </tr>
                                </thead>


                                <tbody v-for="value in products.values">
                                <tr>
                                    <td>MYCT-001</td>
                                    <td>MISSION 6 YELLOW CORN TORTILLAS</td>
                                    <td>12/60 CT</td>
                                    <td>CAJA</td>
                                    <td>20</td>


                                    <td>
                                        <div class="dropdown table-actions-dropdown">
                                            <button class="btn btn-success dropdown-toggle" type="button"
                                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Acciones
                                            </button>
                                            <ul class="dropdown-menu table-actions-dropdown-popup"
                                                aria-labelledby="dropdownMenu2">


                                                <li>
                                                    <a href="">Modificar</a>
                                                    

                                                </li>

                                                <li>
                                                    <a onclick="return confirm('Esta seguro de eliminar esta convalidacion y sus materias?')"
                                                       href="">Eliminar</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>MYCT-001</td>
                                    <td>MISSION 6 YELLOW CORN TORTILLAS</td>
                                    <td>12/60 CT</td>
                                    <td>CAJA</td>
                                    <td>20</td>


                                    <td>
                                        <div class="dropdown table-actions-dropdown">
                                            <button class="btn btn-success dropdown-toggle" type="button"
                                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Acciones
                                            </button>
                                            <ul class="dropdown-menu table-actions-dropdown-popup"
                                                aria-labelledby="dropdownMenu2">


                                                <li>
                                                    <a href="">Modificar</a>
                                                    

                                                </li>

                                                <li>
                                                    <a onclick="return confirm('Esta seguro de eliminar esta convalidacion y sus materias?')"
                                                       href="">Eliminar</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>MYCT-001</td>
                                    <td>MISSION 6 YELLOW CORN TORTILLAS</td>
                                    <td>12/60 CT</td>
                                    <td>CAJA</td>
                                    <td>20</td>


                                    <td>
                                        <div class="dropdown table-actions-dropdown">
                                            <button class="btn btn-success dropdown-toggle" type="button"
                                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Acciones
                                            </button>
                                            <ul class="dropdown-menu table-actions-dropdown-popup"
                                                aria-labelledby="dropdownMenu2">


                                                <li>
                                                    <a href="">Modificar</a>
                                                    

                                                </li>

                                                <li>
                                                    <a onclick="return confirm('Esta seguro de eliminar esta convalidacion y sus materias?')"
                                                       href="">Eliminar</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>MYCT-001</td>
                                    <td>MISSION 6 YELLOW CORN TORTILLAS</td>
                                    <td>12/60 CT</td>
                                    <td>CAJA</td>
                                    <td>20</td>


                                    <td>
                                        <div class="dropdown table-actions-dropdown">
                                            <button class="btn btn-success dropdown-toggle" type="button"
                                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Acciones
                                            </button>
                                            <ul class="dropdown-menu table-actions-dropdown-popup"
                                                aria-labelledby="dropdownMenu2">


                                                <li>
                                                    <a href="">Modificar</a>
                                                    

                                                </li>

                                                <li>
                                                    <a onclick="return confirm('Esta seguro de eliminar esta convalidacion y sus materias?')"
                                                       href="">Eliminar</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                                </tbody>
                            </table>


                        </div>
                        <div id="step-2" class="text-center">
                            <h2 class="StepTitle">Paso 2 Seleccionar</h2>
                           <div>

                               <div class="form-check">
                                   <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked>
                                   <label class="form-check-label" for="exampleRadios1">
                                       Guardar Pedido
                                   </label>
                               </div>
                               <div class="form-check">
                                   <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2" value="option2">
                                   <label class="form-check-label" for="exampleRadios2">
Generar Pedido                                   </label>
                               </div>
                           </div>
                        </div>
                        <div id="step-3" class="text-center">
                            <h2 class="StepTitle">Generar Accion</h2>
                            <p>
                                De Click en "FINISH" para generar acción
                            </p>

                        </div>


                    </div>
                    <!-- End SmartWizard Content -->





                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('styles'); ?>
    ##parent-placeholder-bf62280f159b1468fff0c96540f3989d41279669##

    
    <link rel="stylesheet" href="<?php echo e(asset('css/default.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/tableDynamic.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset('css/customTheme.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset('css/custom/sideBar.css')); ?>">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    ##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
       
    <script src="<?php echo e(asset('js/tableDynamic.js')); ?>"></script>

    <script src="<?php echo e(asset('js/default.js')); ?>"></script>
    <script src="<?php echo e(asset('js/customTheme.js')); ?>"></script>

    
    <script src="<?php echo e(asset('js/data.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>