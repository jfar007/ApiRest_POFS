@extends('admin.layouts.admin')

@section('content')


 {{--   <div class="container-fluid">
        <form action="/curso/{{$curso->id_cursos}}" method="POST" role="form">
            {{ method_field('PATCH') }}
            {{ csrf_field() }}
            <h2>Editar Curso</h2>
            <hr />
            <br />
            @if($errors->any())
                <div align="center" class="alert alert-danger">
                    @foreach($errors->all() as $error)
                        <li>{{$error}}</li>
                    @endforeach
                </div>
            @endif
            <div class="form-horizontal">
                <div class="form-group">
                    <label for="" class="col-md-4 control-label">C&oacute;digo</label>
                    <div class="col-md-4">
                        <input type="text" name="codigo_cursos" value="{{$curso->codigo_cursos}}" class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <label for="" class="col-md-4 control-label">Nombre</label>
                    <div class="col-md-4">
                        <input type="text" name="nombre_cursos" value="{{$curso->nombre_cursos}}" class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <label for="" class="col-md-4 control-label">Grupo</label>
                    <div class="col-md-4">
                        <input type="text" name="grupo_cursos" value="{{$curso->grupo_cursos}}" class="form-control">
                    </div>
                </div>

                <div class="form-group">
                    <label for="" class="col-md-4 control-label">Profesor</label>
                    <div class="col-md-4">
                        <select id="profesores_id_profesores" name="profesores_id_profesores" class="form-control select2" required>
                            <option value="">- Seleccione Profesor-</option>
                            @foreach ($profesor as $prof)
                                <option value="{{ $prof->id_profesores }}"
                                @if(!is_null(old('id_profesores')))
                                    {{old('id_profesores') == $prof->id_profesores ? 'selected' : ''}}
                                        @else
                                    @if(isset($curso))
                                        {{$curso->profesores_id_profesores == $prof->id_profesores ? 'selected' : ''}}
                                            @endif
                                        @endif
                                >{{ $prof->getFullNameAttribute() }} </option>
                            @endforeach
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-md-6 col-md-offset-4">
                        <button type="submit" class="btn btn-primary-ulat">
                            Guardar
                        </button>
                        <a href="/curso" class="btn btn-default">Regresar</a>
                    </div>
                </div>
            </div>
        </form>
    </div>--}}
{{--
    @if($errors->any())
        <div align="center" class="alert alert-danger">
            @foreach($errors->all() as $error)
                <li>{{$error}}</li>
            @endforeach
        </div>
    @endif--}}

    <div >
        {{--Crear Producto--}}
        <div  class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Modificar Producto</h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                            </li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                <ul class="dropdown-menu" role="menu">
                                    <li><a href="#">Configurar</a>
                                    </li>

                                </ul>
                            </li>

                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div id="new-product-content" class="x_content">
                        <br />
                        <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left"  action="{{route('actualizarProducto', ['id' => $product->id])}}"  method="POST" enctype="multipart/form-data" >
                            {{csrf_field()}}
                            <div class="form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="cod_fs">Código<span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input type="text" id="cod_fs" required="required" value="{{$product->cod_fs}}" class="form-control col-md-7 col-xs-12" name="cod_fs">
                                </div>
                            </div>


                            <div class="form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="item">Item<span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input type="text" id="item"  required="required" value="{{$product->item}}" class="form-control col-md-7 col-xs-12" name="item">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="name" class="control-label col-md-3 col-sm-3 col-xs-12">Nombre</label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input id="name" class="form-control col-md-7 col-xs-12" value="{{$product->name}}" type="text" name="name">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="pronunciation_in_english" class="control-label col-md-3 col-sm-3 col-xs-12">Pronunciación en Ingles</label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input id="pronunciation_in_english" class="form-control col-md-7 col-xs-12" value="{{$product->pronunciation_in_english}}" type="text" name="pronunciation_in_english">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="description" class="control-label col-md-3 col-sm-3 col-xs-12">Descripción</label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input id="description" class="form-control col-md-7 col-xs-12" value="{{$product->description}}" type="text" name="description">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="packsize" class="control-label col-md-3 col-sm-3 col-xs-12">Tamaño del paquete</label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input id="packsize" class="form-control col-md-7 col-xs-12"  value="{{$product->packsize}}" type="text" name="packsize" >
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="picture_url" class="control-label col-md-3 col-sm-3 col-xs-12">Subir imagen</label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input id="picture_url" class="form-control col-md-7 col-xs-12"  type="file" name="picture_url">
                                    <div><img src="{{asset('/images/products/'. $product->picture_url)}}" alt=""></div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="category_id" class="control-label col-md-3 col-sm-3 col-xs-12">Categoria</label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <select  id="category_id" class="form-control col-md-7 col-xs-12" v-model="category_id" name="category_id">
                                        @foreach($categories as $category)
                                            <option value="{{$category ->id}} {{$category->id == $product->category_id ? 'selected="selected"' : ''}}">{{$category -> name}} </option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="unit_id" class="control-label col-md-3 col-sm-3 col-xs-12">Unidad</label>
                                <div class="col-md-6 col-sm-6 col-xs-12">

                                    {{--
                                                                    <input id="middle-namess" class="form-control col-md-7 col-xs-12" v-model="unit_id" type="text" name="middle-name">
                                    --}}
                                    <select  id="unit_id" class="form-control col-md-7 col-xs-12" v-model="unit_id" name="unit_id">
                                        @foreach($units as $unit)
                                            <option value="{{$unit ->id}}" {{$unit->id == $product->unit_id ? 'selected="selected"': ''}}>{{$unit -> name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="active" class="control-label col-md-3 col-sm-3 col-xs-12">Activar</label>

                                <div class="col-md-1 col-sm-1 col-xs-12">
                                    <input id="active" class="form-control col-md-3 col-xs-12" value="{{$product->active}}" type="checkbox" {{$product->active == 1 ? 'checked="checked"': '' }} name="active">
                                </div>
                            </div>

                            <div class="ln_solid"></div>
                            <div class="form-group">
                                <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                    <a href="{{route('productos')}}" class="btn btn-danger">Cancelar</a>
                                    <button type="submit" class="btn btn-success">Actualizar Producto</button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>


    </div>
@endsection



@section('styles')
    @parent
    {{--
      link component ui template
  --}}
    <link rel="stylesheet" href="{{asset('css/default.css')}}">
    <link rel="stylesheet" href="{{asset('css/tableDynamic.css')}}">

    {{--last link template--}}
    <link rel="stylesheet" href="{{asset('css/customTheme.css')}}">

    {{--
        links custom
    --}}
    <link rel="stylesheet" href="{{asset('css/custom/sideBar.css')}}">
@endsection


@section('scripts')
    @parent
    <script src="{{asset('js/tableDynamic.js')}}"></script>
    <script src="{{asset('js/customTheme.js')}}"></script>
    <script src="{{asset('js/data.js')}}"></script>



@endsection


