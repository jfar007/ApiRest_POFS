@extends('layouts.app')

@section('page')

{{--Region Content--}}

    @yield('content')

@endsection

{{--@section('styles')

    <link rel="stylesheet" href="{{mix('css/auth.css')}}   ">
@endsection--}}
