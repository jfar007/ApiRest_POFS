<?php $__env->startSection('content'); ?>


    desde dashboard
    <!-- page content -->
    <!-- top tiles -->
   
<?php $__env->stopSection(); ?>


<?php $__env->startSection('styles'); ?>
    ##parent-placeholder-bf62280f159b1468fff0c96540f3989d41279669##

    <link rel="stylesheet" href="<?php echo e(asset('css/default.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/tableDynamic.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset('css/customTheme.css')); ?>">


    <link rel="stylesheet" href="<?php echo e(asset('css/custom/sideBar.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    ##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
    <script src="<?php echo e(asset('js/tableDynamic.js')); ?>"></script>
    <script src="<?php echo e(asset('js/customTheme.js')); ?>"></script>
    <script src="<?php echo e(asset('js/data.js')); ?>"></script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>