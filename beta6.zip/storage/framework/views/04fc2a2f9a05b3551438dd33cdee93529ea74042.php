<?php $__env->startSection('body_class','login'); ?>

<?php $__env->startSection('content'); ?>
    <div class="animate form login_form row" >
        <div  style=" background: url('<?php echo e(asset('/images/background-login.jpg')); ?>');  height:100vh" class="col-xs-12 col-sm-6 col-md-6 col-lg-6 div-hide">

        </div>

        <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
            <div class="login_wrapper">
                <div >
                    <section class="login_content">
                        <div class="logo-container"><img src="<?php echo e(asset('images/logo.png')); ?>" alt=""></div>
                        <form method="POST"  action="<?php echo e(route('login')); ?>" >
                            <?php echo e(csrf_field()); ?>

                            <h1>Iniciar Cuenta</h1>
                            <div  style="text-align: left !important;" class="field form-group<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
                                <label for="username" class="field-label">Usuario</label>

                                <input id="email"   type="text" class="form-control field-input" name="username" value="<?php echo e(old('username')); ?>"  autofocus>

                                <?php if($errors->has('username')): ?>
                                    <span class="help-block">
                        <strong><?php echo e($errors->first('username')); ?></strong>
                    </span>
                                <?php endif; ?>
                            </div>

                            <div style="text-align: left !important;" class="field form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                <label for="password" class="field-label">Contraseña</label>

                                <input id="password" title="Presione este botón una vez que haya ingresado el usuario y la contraseña" type="password" class="form-control field-input" name="password" >

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group<?php echo e($errors->has('locked') ? ' has-error' : ''); ?>">
                                <button  style="background-color: #662482; border: none;" type="submit" class="btn btn-success pull-left">Ingresar</button>

                                <?php if($errors->has('locked')): ?>
                                    <span class="help-block">
                        <strong><?php echo e($errors->first('locked')); ?></strong>
                    </span>
                                <?php endif; ?>
                            </div>

                            <div>

                                
                                <a class="reset_pass pull-right" href="">
                                    Recuperar Contraseña
                                </a>
                            </div>

                            <div class="clearfix"></div>


                            <div class="separator">
                                <p class="change_link">No tienes una cuenta?
                                    <a href=""
                                       class="to_register"> Registrarse </a>
                                </p>

                                <div class="clearfix"></div>
                                <br/>

                                <div>
                                    <p>&copy; <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?>.
                                </div>
                            </div>
                        </form>
                    </section>
                </div>
            </div>

        </div>
    </div>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('styles'); ?>
    ##parent-placeholder-bf62280f159b1468fff0c96540f3989d41279669##
    <link rel="stylesheet" href="<?php echo e(asset('css/default.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/customTheme.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/custom/customLogin.css')); ?>">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    ##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
    <script src="<?php echo e(asset('js/tableDynamic.js')); ?>"></script>
    <script src="<?php echo e(asset('js/customTheme.js')); ?>"></script>
   
<?php $__env->stopSection(); ?>


<?php echo $__env->make('auth.layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>