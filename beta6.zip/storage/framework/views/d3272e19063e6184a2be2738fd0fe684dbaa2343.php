<?php $__env->startSection('content'); ?>


 


    <div >
        
        <div  class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Modificar Producto</h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                            </li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                <ul class="dropdown-menu" role="menu">
                                    <li><a href="#">Configurar</a>
                                    </li>

                                </ul>
                            </li>

                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div id="new-product-content" class="x_content">
                        <br />
                        <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left"  action="<?php echo e(route('actualizarProducto', ['id' => $product->id])); ?>"  method="POST" enctype="multipart/form-data" >
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="cod_fs">Código<span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input type="text" id="cod_fs" required="required" value="<?php echo e($product->cod_fs); ?>" class="form-control col-md-7 col-xs-12" name="cod_fs">
                                </div>
                            </div>


                            <div class="form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="item">Item<span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input type="text" id="item"  required="required" value="<?php echo e($product->item); ?>" class="form-control col-md-7 col-xs-12" name="item">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="name" class="control-label col-md-3 col-sm-3 col-xs-12">Nombre</label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input id="name" class="form-control col-md-7 col-xs-12" value="<?php echo e($product->name); ?>" type="text" name="name">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="pronunciation_in_english" class="control-label col-md-3 col-sm-3 col-xs-12">Pronunciación en Ingles</label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input id="pronunciation_in_english" class="form-control col-md-7 col-xs-12" value="<?php echo e($product->pronunciation_in_english); ?>" type="text" name="pronunciation_in_english">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="description" class="control-label col-md-3 col-sm-3 col-xs-12">Descripción</label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input id="description" class="form-control col-md-7 col-xs-12" value="<?php echo e($product->description); ?>" type="text" name="description">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="packsize" class="control-label col-md-3 col-sm-3 col-xs-12">Tamaño del paquete</label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input id="packsize" class="form-control col-md-7 col-xs-12"  value="<?php echo e($product->packsize); ?>" type="text" name="packsize" >
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="picture_url" class="control-label col-md-3 col-sm-3 col-xs-12">Subir imagen</label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input id="picture_url" class="form-control col-md-7 col-xs-12"  type="file" name="picture_url">
                                    <div><img src="<?php echo e(asset('/images/products/'. $product->picture_url)); ?>" alt=""></div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="category_id" class="control-label col-md-3 col-sm-3 col-xs-12">Categoria</label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <select  id="category_id" class="form-control col-md-7 col-xs-12" v-model="category_id" name="category_id">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category ->id); ?> <?php echo e($category->id == $product->category_id ? 'selected="selected"' : ''); ?>"><?php echo e($category -> name); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="unit_id" class="control-label col-md-3 col-sm-3 col-xs-12">Unidad</label>
                                <div class="col-md-6 col-sm-6 col-xs-12">

                                    
                                    <select  id="unit_id" class="form-control col-md-7 col-xs-12" v-model="unit_id" name="unit_id">
                                        <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($unit ->id); ?>" <?php echo e($unit->id == $product->unit_id ? 'selected="selected"': ''); ?>><?php echo e($unit -> name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="active" class="control-label col-md-3 col-sm-3 col-xs-12">Activar</label>

                                <div class="col-md-1 col-sm-1 col-xs-12">
                                    <input id="active" class="form-control col-md-3 col-xs-12" value="<?php echo e($product->active); ?>" type="checkbox" <?php echo e($product->active == 1 ? 'checked="checked"': ''); ?> name="active">
                                </div>
                            </div>

                            <div class="ln_solid"></div>
                            <div class="form-group">
                                <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                    <a href="<?php echo e(route('productos')); ?>" class="btn btn-danger">Cancelar</a>
                                    <button type="submit" class="btn btn-success">Actualizar Producto</button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>


    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('styles'); ?>
    ##parent-placeholder-bf62280f159b1468fff0c96540f3989d41279669##
    
    <link rel="stylesheet" href="<?php echo e(asset('css/default.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/tableDynamic.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset('css/customTheme.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset('css/custom/sideBar.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    ##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
    <script src="<?php echo e(asset('js/tableDynamic.js')); ?>"></script>
    <script src="<?php echo e(asset('js/customTheme.js')); ?>"></script>
    <script src="<?php echo e(asset('js/data.js')); ?>"></script>



<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>