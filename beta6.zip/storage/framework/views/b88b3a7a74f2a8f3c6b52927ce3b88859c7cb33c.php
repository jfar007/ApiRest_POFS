<!-- top navigation -->
<div class="top_nav">
    <div style="background: #2A3F54" class="nav_menu">
        <nav>
            <div class="nav toggle">
                <a id="menu_toggle"><i style="color: white" class="fa fa-bars"></i></a>
            </div>

            <div id="logo-sections" class="navbar nav_title"><a href="#" class="site_title"><img height="50px"
                                                                                                          width="210px"
                                                                                                          src="<?php echo e(asset('images/logo.png')); ?>"
                                                                                                          alt=""></a>
            </div>
            <ul class="nav navbar-nav navbar-right">
                <li class="">
                    <a style="color: #ffffff" href="<?php echo e(route('logout')); ?>" class="user-profile" aria-expanded="false"
                       onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        Logout
                        <span class=" fa fa-sign-out"></span>
                    </a>

                    <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>" role="form"
                          style="display: none;">
                        <?php echo e(csrf_field()); ?>

                    </form>

                </li>

                <li role="presentation" class="dropdown">
                    <a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown"
                       aria-expanded="false">
                        <i style="color: white"  class="fa fa-bell"></i>
                        <span class="badge bg-green">6</span>
                    </a>
                    
                </li>
            </ul>
        </nav>
    </div>
</div>
<!-- /top navigation -->

